import React from 'react';
import './App.css';

function App() {
  return (
    <div className="App">
      <header>
        <h1>Nazim Sadiku</h1>
        <p>Full-Stack Web Developer</p>
      </header>
      <section>
        <h2>About Me</h2>
        <p>I am passionate about building modern, responsive web applications. My goal is to become a skilled full-stack developer by working on real-world projects and continuing to learn and grow.</p>
      </section>
      <section>
        <h2>Projects</h2>
        <ul>
          <li><a href="#">Job Application Tracker</a></li>
          <li><a href="#">Expense Tracker</a></li>
          <li><a href="#">Task Manager</a></li>
        </ul>
      </section>
      <section>
        <h2>Contact</h2>
        <p>Email: nazim@example.com</p>
        <p>GitHub: <a href="https://github.com/">github.com/yourprofile</a></p>
      </section>
    </div>
  );
}

export default App;
