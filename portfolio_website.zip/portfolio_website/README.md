# Portfolio Website

A personal portfolio website for showcasing your full-stack projects.

## Features
- About Me section
- List of major projects
- Contact information

## Setup
1. Run `npm install`
2. Run `npm start` to view in browser
3. Deploy to GitHub Pages, Netlify, or Vercel
